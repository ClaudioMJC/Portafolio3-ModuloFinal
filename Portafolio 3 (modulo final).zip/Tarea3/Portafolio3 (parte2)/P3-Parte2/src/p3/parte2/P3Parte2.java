/*
 Claudio Jiménez Castro
06/09/2023
 */
package p3.parte2;

import java.util.Random;  // se importa la clase ramdom para aleatorios
public class P3Parte2 {

    public static void main(String[] args) {
        
        int[] arregloAleatorios = new int[15];  //iniacializamos el arreglo para 15 enteros
        int contador = 0;  //el contador ayudará a llevar un conteo de cuantos números se han generado e ingresarlos al arreglo
        Random random = new Random(); //Creo una instancia de la clase Random para generar números aleatorios

        while (contador < arregloAleatorios.length) { //bucle while se ejecuta hasta generar y agregar 15 números al arreglo
            int numeroAleatorio = random.nextInt(20) + 1; // Genera un número aleatorio entre 1 y 20

            // Verifica si el número ya está en el vector
            boolean repetido = false;
            for (int i = 0; i < contador; i++) {                 
                if (arregloAleatorios[i] == numeroAleatorio) {     
                    repetido = true;
                    break;  // Sale del bucle tan pronto como encuentra un número repetido.
                    //no es necesario seguir recorriendo el arreglo porque ya sabemos que no es un número único
                }
            }

            // Si no está repetido,  se agrega al arreglo en la posición contador y luego incrementamos contador en 1.
            if (!repetido) {
                arregloAleatorios[contador] = numeroAleatorio;  
                contador++;
            }
        }
        //
        // Imprime el vector resultante
        for (int i = 0; i < arregloAleatorios.length; i++) {
            System.out.print(arregloAleatorios[i] + " ");
        }
        
    }
    
}
