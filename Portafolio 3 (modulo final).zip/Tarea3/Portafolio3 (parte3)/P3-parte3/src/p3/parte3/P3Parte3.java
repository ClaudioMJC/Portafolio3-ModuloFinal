/*
Claudio Jiménez Castro
06/09/2023


 */
package p3.parte3;


import java.util.Random;
import java.util.Scanner;

public class P3Parte3 {
    private static int[][] matriz;
    private static int sizeMatriz;
    private static boolean matrizLlena = false;
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {    //switch que se ejecuta según la opción escogida por el usuario
            //se continuará ejecutando hasta que una opción del menú rompa el bucle con la opcion de salir
            int opcion = mostrarMenu();

            switch (opcion) {
                case 1:
                    llenarMatrizAleatoriamente();
                    matrizLlena = true;
                    break;
                case 2:
                    if (matrizLlena) {  //apartir de acá en adelante si la matriz no está llena, se indicará que se debe llenar primero
                        mostrarMatriz();
                    } else {
                        System.out.println("Primero debe llenar la matriz.");
                    }
                    break;
                case 3:
                    if (matrizLlena) {
                        sumarFila();
                    } else {
                        System.out.println("Primero debe llenar la matriz.");
                    }
                    break;
                case 4:
                    if (matrizLlena) {
                        sumarColumna();
                    } else {
                        System.out.println("Primero debe llenar la matriz.");
                    }
                    break;
                case 5:
                    if (matrizLlena) {
                        sumarDiagonalPrincipal();
                    } else {
                        System.out.println("Primero debe llenar la matriz.");
                    }
                    break;
                case 6:
                    if (matrizLlena) {
                        sumarDiagonalInversa();
                    } else {
                        System.out.println("Primero debe llenar la matriz.");
                    }
                    break;
                case 7:
                    if (matrizLlena) {
                        calcularPromedioMatriz();
                    } else {
                        System.out.println("Primero debe llenar la matriz.");
                    }
                    break;
                case 8:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, ingrese una opción válida.");
                    break;
            }
        }
    }

    private static int mostrarMenu() {
        // Muestra el menú y devuelve la opción seleccionada por el usuario.
        System.out.println("Menu:");
        System.out.println("1) Llenar la matriz con números aleatorios entre 1 y 200.");
        System.out.println("2) Mostrar la matriz.");
        System.out.println("3) Sumar una fila.");
        System.out.println("4) Sumar una columna.");
        System.out.println("5) Sumar la diagonal principal.");
        System.out.println("6) Sumar la diagonal inversa.");
        System.out.println("7) El promedio de los valores de la matriz.");
        System.out.println("8) Salir.");
        System.out.print("Seleccione una opción: ");
        return scanner.nextInt();
    }

    private static void llenarMatrizAleatoriamente() {
        // Llena la matriz con números aleatorios en el rango [1, 200].
        System.out.print("Ingrese la dimensión de la matriz indicando un número (n): ");
        sizeMatriz = scanner.nextInt();
        matriz = new int[sizeMatriz][sizeMatriz];
        Random random = new Random();
        for (int i = 0; i < sizeMatriz; i++) {   //se hace el llenado para filas y columnas
            for (int j = 0; j < sizeMatriz; j++) {
                matriz[i][j] = random.nextInt(200) + 1;
            }
        }
        matrizLlena = true;
        System.out.println("Matriz llenada aleatoriamente.");
    }

    private static void mostrarMatriz() {
        // Muestra la matriz en la consola.
        System.out.println("Matriz:");
        for (int i = 0; i < sizeMatriz; i++) {
            for (int j = 0; j < sizeMatriz; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println();
        }
    }

    private static void sumarFila() {
        // Suma los valores de una fila especificada por el usuario.
        System.out.print("Ingrese el número de fila a sumar (0-" + (sizeMatriz - 1) + "): ");  //Solicita al usuario que ingrese el número de fila a sumar.
        int fila = scanner.nextInt();
        // Verifica si el número de fila ingresado es válido
        if (fila >= 0 && fila < sizeMatriz) {
            int suma = 0; //Inicializa una variable "suma" para almacenar la suma de los valores de la fila.
            //Se recorre cada columna de la fila y suma sus valores.
            for (int j = 0; j < sizeMatriz; j++) {
                suma += matriz[fila][j];
            }  //Muestra el resultado de la suma de la fila especificada
            System.out.println("La suma de la fila " + fila + " es: " + suma);
        } else {  //Si el número de fila no es válido, muestra un mensaje de error.
            System.out.println("Número de fila no válido.");
        }
    }

    private static void sumarColumna() {
        // Suma los valores de una columna especificada por el usuario.
        System.out.print("Ingrese el número de columna a sumar (0-" + (sizeMatriz - 1) + "): ");
        int columna = scanner.nextInt();
        if (columna >= 0 && columna < sizeMatriz) {  //similar al método de sumar fila, solo que ahora se recorren las filas 
            int suma = 0;
            for (int i = 0; i < sizeMatriz; i++) {
                suma += matriz[i][columna];
            }
            System.out.println("La suma de la columna " + columna + " es: " + suma);
        } else {
            System.out.println("Número de columna no válido.");
        }
    }

    private static void sumarDiagonalPrincipal() {
        // Suma los valores de la diagonal principal.
        int suma = 0;
        for (int i = 0; i < sizeMatriz; i++) {   //el bucle va desde la primera fila y columna de la matriz, hasta la ultima columna y fila
            suma += matriz[i][i];           //de esta forma se asegura que se solo se recorran los elementos de la diagonal principal
        }
        System.out.println("La suma de la diagonal principal es: " + suma);
    }

    private static void sumarDiagonalInversa() {
        // Suma los valores de la diagonal inversa.
        
        //método similar al anterior, solo que en este caso le resto el índice i al tamaño de la matriz menos 1 (sizeMatriz - 1 - i). Esto permite recorrer la diagonal inversa, que va desde la esquina superior derecha a la esquina inferior izquierda de la matriz
        int suma = 0;
        for (int i = 0; i < sizeMatriz; i++) {
            suma += matriz[i][sizeMatriz - 1 - i];
        }
        System.out.println("La suma de la diagonal inversa es: " + suma);
    }

    private static void calcularPromedioMatriz() {
        // Calcula el promedio de los valores de la matriz.
        int suma = 0; //guarda resultado
        for (int i = 0; i < sizeMatriz; i++) {  //doble for para filas y luego columnas
            for (int j = 0; j < sizeMatriz; j++) {
                suma += matriz[i][j];  //se suma cada valor de la celda actual a la variable suma
            }
        }
        //
        // se calcula el promedio dividiendo la suma del total de los valores de cada celda de la matriz entre el número de filas y columnas
        double promedio = (double) suma / (sizeMatriz * sizeMatriz);
        System.out.println("El promedio de los valores de la matriz es: " + promedio);
    }
}

