/*
 Claudio Mauricio Jiménez Castro
06/09/'2
 */
package portafolio3;

/**
 *
 * @author Claudio
 */
import java.util.Scanner;
public class Portafolio3 {

   
    public static void main(String[] args) {
        
        int cantidadTrabajadores = solicitarCantidadTrabajadores();
        String[] nombres = new String[cantidadTrabajadores];
        int[] edades = new int[cantidadTrabajadores];
        double[] salarios = new double[cantidadTrabajadores];
        boolean trabajadoresIngresados = false;

    while (true) {
        int opcion = mostrarMenu();

        switch (opcion) {
            case 1:
                ingresarDatosTrabajadores(nombres, edades, salarios);
                trabajadoresIngresados = true;
                break;
            case 2:
                //ordenarPorNombre(nombres, edades, salarios);
                
                if (trabajadoresIngresados) {
                    ordenarPorNombre(nombres, edades, salarios);
                } else {
                    System.out.println("Debe ingresar los datos de los trabajadores primero.");
                }
                
                break;
            case 3:
                if (trabajadoresIngresados) {
                    ordenarPorEdad(nombres, edades, salarios);
                } else {
                    System.out.println("Debe ingresar los datos de los trabajadores primero.");
                }
                break;
            case 4:
                if (trabajadoresIngresados) {
                    ordenarPorSalario(nombres, edades, salarios);
                } else {
                    System.out.println("Debe ingresar los datos de los trabajadores primero.");
                }
                break;
            case 5:
                if (trabajadoresIngresados) {
                    mostrarInformacionTrabajadores(nombres, edades, salarios);
                } else {
                    System.out.println("Debe ingresar los datos de los trabajadores primero.");
                }
                break;
            case 6:
                System.exit(0);
            default:
                System.out.println("Opción no válida. Por favor, ingrese una opción válida.");
                break;
        }
    }
        
        
        
        
    }
    
            //método simple para pedir la médida de los arreglos
     public static int solicitarCantidadTrabajadores() {
     Scanner scanner = new Scanner(System.in);
     System.out.print("Ingrese la cantidad de trabajadores: ");
     return scanner.nextInt();
    }
    
    //basádos en la cantidad de trabajadores, se le pedirá a la persona que ingrese la información para esos trabajadores
    //se recopila e ingresa al mismo tiempo la información para los otros arreglos
    public static void ingresarDatosTrabajadores(String[] nombres, int[] edades, double[] salarios) {
    Scanner scanner = new Scanner(System.in);
    for (int i = 0; i < nombres.length; i++) {
        System.out.println("Ingrese los datos del trabajador " + (i + 1));
        System.out.print("Nombre: ");
        nombres[i] = scanner.next();
        System.out.print("Edad: ");
        edades[i] = scanner.nextInt();
        System.out.print("Salario: ");
        salarios[i] = scanner.nextDouble();
    }
    
    }
    //Ordenamiento #1 Burbuja
    
    public static void ordenarPorNombre(String[] nombres, int[] edades, double[] salarios) {
    int n = nombres.length;
    for (int i = 0; i < n - 1; i++) {  // primer ciclo de iteración sobre cada elemento del arreglo, hasta n (longitud (-1) )
        for (int j = 0; j < n - i - 1; j++) {  //bucle interno compara pares de elementos y los acomoda
                // se resta 1 de n para no salirse del límite superior del arreglo al comparar elementos
                //Se resta i para evitar comparar elementos que ya han sido colocados en su posición final. 
            if (nombres[j].compareTo(nombres[j + 1]) > 0) {  //se determina cual nombres es mayor que otro debido a su órden alfabético
                // Intercambia nombres
                String temporalNombre = nombres[j];  
                nombres[j] = nombres[j + 1];
                nombres[j + 1] = temporalNombre;  //cuando se intercambian los elementos en el arreglo nombres para mantenerlos en orden     alfabético, los elementos correspondientes en los arreglos edades y salarios también se intercambian para manter la coherencia 
                
                // Intercambia edades
                int temporalEdad = edades[j];    //La estructura aquí implementada permite que exista siempre un orden
                edades[j] = edades[j + 1];    //coherente en la información que corresponde a cada trabajador, aún modificando el orden 
                edades[j + 1] = temporalEdad;  // se emplean variables temporales que guardan la información de los arreglos
                
                // Intercambia salarios
                double temporalSalario = salarios[j];
                salarios[j] = salarios[j + 1];
                salarios[j + 1] = temporalSalario;
            }
        }
    }
}


//Ordenamiento 2, por selección 
    
    public static void ordenarPorEdad(String[] nombres, int[] edades, double[] salarios) {
    int n = edades.length;
    for (int i = 0; i < n - 1; i++) {  // bucle externo que recorrerá el arreglo 
        int minimoIndex = i;
        for (int j = i + 1; j < n; j++) {  //Bucle interno busca el índice del elemento con la edad más baja dentro del rango no ordenado.
            if (edades[j] < edades[minimoIndex]) {
                minimoIndex = j; //representa el índice del elemento con la edad más baja dentro del rango no ordenado "minimoIndex".
            }        //cada vez que se encuentra un índice más pequeño se actualiza el valor del minimoIndex
        }
        // Intercambia nombres
        String tempNombre = nombres[minimoIndex];
        nombres[minimoIndex] = nombres[i];  //conforme el ciclo se ejecuta y actualiza se intercambia el valor de minimo index con i, de esta forma se logra que los los elementos queden ordenados
        nombres[i] = tempNombre;
        
        // Intercambia edades
        int tempEdad = edades[minimoIndex];  //los otros arreglos se van ordenando de la misma forma
        edades[minimoIndex] = edades[i];
        edades[i] = tempEdad;
        
        // Intercambia salarios
        double tempSalario = salarios[minimoIndex];
        salarios[minimoIndex] = salarios[i];
        salarios[i] = tempSalario;
    }
}

    //Tercera forma de ordenamiento: "Por inserción"
    
    
    public static void ordenarPorSalario(String[] nombres, int[] edades, double[] salarios) {
    int n = salarios.length;
    for (int i = 1; i < n; i++) {
        double guardaSalarios = salarios[i]; // como se mueven los elementos más pequeños hacia adelante en el arreglo, hay retener la información asociada con ellos, es por eso que uso las variables y guardo la información de los arreglos
        String guardaNombre = nombres[i];
        int guardaEdad = edades[i];
        int j = i - 1;//se inicializa j 
        while (j >= 0 && salarios[j] > guardaSalarios ) {  //Este bucle recorre hacia atrás desde la posición actual (i) hasta el principio del arreglo o hasta que encuentre un elemento que sea menor que guardaSalarios en su subíndice actual
            salarios[j + 1] = salarios[j];
            nombres[j + 1] = nombres[j];  //conforme se vaya encontrando un elemento mayor que guardaSalario[i] se mueve para acomodar los elementos,
            edades[j + 1] = edades[j];   //de la misma forma para los otros arreglos
            j = j - 1;
        }
        salarios[j + 1] = guardaSalarios ;
        nombres[j + 1] = guardaNombre;  //De la misma forma si se ordena un arreglos los otros se acomodan, para mantener la coerencia
        edades[j + 1] = guardaEdad;
    }
}

    
    public static void mostrarInformacionTrabajadores(String[] nombres, int[] edades, double[] salarios) {
    System.out.println("Información de los trabajadores:");
    for (int i = 0; i < nombres.length; i++) {
        System.out.println("Trabajador " + (i + 1));
        System.out.println("Nombre: " + nombres[i]);
        System.out.println("Edad: " + edades[i]);
        System.out.println("Salario: " + salarios[i]);
        System.out.println();
    }
}
    
    
    public static int mostrarMenu() {
    System.out.println("Menú:");
   
    System.out.println("1) Introducir los datos de los trabajadores.");
    System.out.println("2) Ordenar por nombre.");
    System.out.println("3) Ordenar por edad.");
    System.out.println("4) Ordenar por salario.");
    System.out.println("5) Mostrar información de los empleados.");
    System.out.println("6) Salir.");
    System.out.print("Elija una opción: ");

    Scanner scanner = new Scanner(System.in);
    int opcion = scanner.nextInt();

    return opcion;
}


    
    
    
    
}
